# Software-Engineering
For Software Engineering Project


Project SummaryCharityDrop is a paid professional solicitor selected by the AncientOrder of the 
Purple Peaceand the National Federation of the Advancement of Goodnessto raise funds through the collection of donated clothing and household items. 
These items are converted into critical dollars needed to assist thoseorganizations in their mission.
The purpose of the Charitable Donation Scheduler is to provide donors with the ability to schedule a pickup at their house. 
Administratively, the interface should only allow a donor to schedule a pickup on days when the truck will be in their area


The end goal of this project is to get a website working on a local host that uses PHP, HTML, CSS, JS, and mySQL to run a website.
